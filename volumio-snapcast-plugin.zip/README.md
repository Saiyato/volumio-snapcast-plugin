# volumio-snapcast-plugin
Volumio 2 SnapCast plugin, to easily manage SnapCast functionality

Simple how-to:
1. Install the zip-package in Volumio 2
2. Configure the output format (sampling, bit depth, codec)
3. Configure the soundcard for output
4. Enjoy in-sync music

The package will install both the client and server, you can en- or disable any component in the plugin settings.

Please note that I did not write the SnapCast application, I merely supplied means to easily install it.
You can find the SnapCast project here: https://github.com/badaix/snapcast
